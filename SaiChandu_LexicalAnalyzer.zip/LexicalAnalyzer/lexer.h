#ifndef LEXER_H
#define LEXER_H

#define MAX_KEYWORDS 32
#define MAX_TOKEN_SIZE 100

static const char* keywords[MAX_KEYWORDS] = {
	"int", "float", "return", "if", "else", "while", "for", "do", "break", "continue","volatile","goto","auto","register","static","return","enum",
	"char", "double", "void", "switch", "case", "default", "const", "static", "sizeof", "struct","signed","unsigned","short","long","typedef"
};
// static const char operators1[] = {"<=",">=","++","--","!=","<<",">>","==","?:","+=","-=","=","/=","%=","<<=",">>=","&=","^=","&&","||"};
static const char* operators = "+-*/%=!<>|&()~^";

static const char* specialCharacters = ".,;{}[]";

static const char* remainingCharacters = "_@$?";

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

typedef enum
{
    FAILURE,
    SUCCESS
} return_val;

typedef enum {
    KEYWORD,
    OPERATOR,
    SPECIAL_CHARACTER,
    CONSTANT,
    IDENTIFIER,
    UNKNOWN
} TokenType;

typedef struct {
    char lexeme[MAX_TOKEN_SIZE];
    TokenType type;
} Token;

// return_val isalpha(char ch);
void print_token(Token token);
Token set_token(char *buffer);
void brace_error(char ch);
void sbrace_error(char ch);

int initializeLexer(const char* filename,char *prog);
Token getNextToken();
void categorizeToken(Token* token);
int isKeyword(const char* str);
int isOperator(const char *str);
int isSpecialCharacter(const char *str);
int isConstant(const char* str);
int isIdentifier(const char* str);

#endif
