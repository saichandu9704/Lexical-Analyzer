#include<stdio.h>
int main()
{
    char 1ch1 = 154g;
    scanf("%c",&ch);
    printf("%c",ch;
    return 0;        
}

