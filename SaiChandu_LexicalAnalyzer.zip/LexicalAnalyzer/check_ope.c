#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<ctype.h>
#include <unistd.h>
#include "lexer.h"


int isKeyword(const char* str)
{
    for(int i=0;i<32;i++)
    {
        if(strcmp(keywords[i],str)==0)
        {
            return SUCCESS;
        }
    }
    return FAILURE;
}

int isOperator(const char *str)
{
    int i=0;
    while(operators[i])
    {
        if(operators[i++]==str[0])
        {
            return SUCCESS;
        }
    }
    return FAILURE;
}

int isSpecialCharacter(const char *str)
{
    int i=0;
    while(specialCharacters[i])
    {
        if(specialCharacters[i++]==str[0])
        {
            return SUCCESS;
        }
    }
    return FAILURE;
}

int isConstant(const char* str)
{
    int i=0;
    while(str[i])
    {
        if(str[i]>='0' && str[i]<='9')
        {
            i++;
        }
        else
        {
            return FAILURE;
        }
    }
    return SUCCESS;
}

int isIdentifier(const char* str)
{

}

void print_token(Token token)
{
    if(token.type==0)
    {
        printf("Token type \"%s\": token is \"%s\"\n","KEYWORD",token.lexeme);
    }
    else if(token.type==1)
    {
        printf("Token type \"%s\": token is \"%s\"\n","OPERATOR",token.lexeme);
    }
    else if(token.type==2)
    {
        printf("Token type \"%s\": token is \"%s\"\n","SPECIAL_CHARACTER",token.lexeme);
    }
    else if(token.type==3)
    {
        printf("Token type \"%s\": token is \"%s\"\n","CONSTANT",token.lexeme);
    }
    else if(token.type==4)
    {
        printf("Token type \"%s\": token is \"%s\"\n","IDENTIFIER",token.lexeme);
    }
    else if(token.type==5)
    {
        printf("Token type \"%s\": token is \"%s\"\n","UNKNOWN",token.lexeme);
    }
}