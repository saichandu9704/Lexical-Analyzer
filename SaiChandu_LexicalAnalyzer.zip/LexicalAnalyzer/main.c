#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<ctype.h>
#include <unistd.h>
#include "lexer.h"

int brace_count=0;
int sbrace_flag=0;

int main(int argc, char *argv[]) 
{
    if(argc==2)
    {
        system("clear");
        char buffer[20],ch;
        int count=0,flag=0,flag1=0;
        FILE *ptr=fopen(argv[1],"r");
        while((ch=fgetc(ptr))!=EOF)
        {
            if(ch=='#')
            {
                flag=1;
            }
            else if(ch=='\n')
            {
                flag=0;
            }
            if(flag==1)
            {
                continue;
            }
            
            if(ch=='"' && flag1==0)
            {
                flag1=1;
                buffer[count++]=ch;
            }
            else if(ch=='"' && flag1==1)
            {
                flag1=0;
                buffer[count++]=ch;
            }
            else if(flag1==1)
            {
                buffer[count++]=ch;
            }
            else if(isalpha(ch))
            {
                buffer[count++]=ch;
            }
            else if(isdigit(ch))
            {
                buffer[count++]=ch;
            }
            else
            {
                if(count>0)
                {
                    buffer[count]='\0';
                    count=0;
                    Token token=set_token(buffer);
                    print_token(token);
                    if(ch!=' ')
                    {
                        token=set_token(&ch);
                        print_token(token);
                    }
                }
                else if(count==0 && ch!=' ' && ch!='\n')
                {
                    if(ch==';' && sbrace_flag==1)
                    {
                        printf(ANSI_COLOR_RED"Error:You miss Brace(() or [])\n"ANSI_COLOR_RESET);
                        return 1;
                    }
                    if((ch==')' || ch==']') && sbrace_flag==1)
                    {
                        sbrace_flag=0;
                    }
                    
                    brace_error(ch);
                    sbrace_error(ch);
                    buffer[count++]=ch;
                    buffer[count]='\0';
                    count=0;
                    Token token=set_token(buffer);
                    print_token(token);
                }
            }
        }
        if(brace_count!=0)
        {
            printf(ANSI_COLOR_RED"Error:You miss %d Brace\n"ANSI_COLOR_RESET,brace_count);
        }
    }
    else
    {
        printf("Invalid arguments\n");
        return 1;
    }
    return 0;
}


Token set_token(char *buffer)
{
    Token token;
    strcpy(token.lexeme,buffer);
    if(isKeyword(buffer))
    {
        token.type=KEYWORD;
    }
    else if(isOperator(buffer))
    {
        token.type=OPERATOR;
    }
    else if(isSpecialCharacter(buffer))
    {
        token.type=SPECIAL_CHARACTER;
    }
    else if(isConstant(buffer))
    {
        token.type=CONSTANT;
    }
    else if(isIdentifier(buffer))
    {
        token.type=IDENTIFIER;
    }
    return token;
}

void brace_error(char ch)
{
    if(ch=='{')
    {
        brace_count++;
    }
    else if(ch=='}')
    {
        brace_count--;
    }

}

void sbrace_error(char ch)
{
    if(ch=='(' || ch=='[')
    {
        sbrace_flag=1;
    }
}